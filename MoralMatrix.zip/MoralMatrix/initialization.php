<?php
// initialization.php

include __DIR__ . '/config.php';

$servername = $database_settings['servername'];
$username   = $database_settings['username'];
$password   = $database_settings['password'];
$dbname     = $database_settings['dbname'];

/**
 * Fail fast on query errors with context.
 */
function handleQueryError($sql, $conn) {
    die("Error executing query:<br><pre>$sql</pre><br>MySQL said: " . $conn->error);
}

/**
 * Helper to exec and die on error
 */
function execOrDie($conn, $sql) {
    if ($conn->query($sql) === FALSE) {
        handleQueryError($sql, $conn);
    }
}

/**
 * 1) Connect without DB and ensure the database exists
 */
$conn = new mysqli($servername, $username, $password);
if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

$sqlCreateDatabase = "CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
execOrDie($conn, $sqlCreateDatabase);
$conn->close();

/**
 * 2) Connect to the database we just ensured
 */
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

/**
 * 3) Create schemas (InnoDB + utf8mb4 everywhere)
 */

/* Accounts Table */
$sqlCreateLoginSchema = "CREATE TABLE IF NOT EXISTS accounts (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    id_number VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL UNIQUE,
    account_type ENUM('super_admin', 'administrator', 'ccdu', 'faculty', 'student', 'security') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
execOrDie($conn, $sqlCreateLoginSchema);

/* Super Admin Table */
$sqlCreateSuperAdminSchema = "CREATE TABLE IF NOT EXISTS super_admin (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    id_number VARCHAR(50) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    email VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
execOrDie($conn, $sqlCreateSuperAdminSchema);

/* Faculty table */
$sqlCreateFacultyAccountSchema = "CREATE TABLE IF NOT EXISTS faculty_account (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    faculty_id VARCHAR(50) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    email VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL UNIQUE,
    photo BLOB,
    institute VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
execOrDie($conn, $sqlCreateFacultyAccountSchema);

/* CCDU table */
$sqlCreateCcduAccountSchema = "CREATE TABLE IF NOT EXISTS ccdu_account (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    ccdu_id VARCHAR(50) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    email VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL UNIQUE,
    photo BLOB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
execOrDie($conn, $sqlCreateCcduAccountSchema);

/* Security table */
$sqlCreateSecurityAccountSchema = "CREATE TABLE IF NOT EXISTS security_account (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    security_id VARCHAR(50) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    email VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL UNIQUE,
    photo BLOB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
execOrDie($conn, $sqlCreateSecurityAccountSchema);

/* Student table */
$sqlCreateStudentAccountSchema = "CREATE TABLE IF NOT EXISTS student_account (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(50) NOT NULL UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    email VARCHAR(50) NOT NULL UNIQUE,
    photo BLOB,
    institute VARCHAR(255),
    course VARCHAR(255),
    level INT,
    section VARCHAR(50),
    guardian VARCHAR(50),
    guardian_mobile VARCHAR(15),
    password VARCHAR(255) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
execOrDie($conn, $sqlCreateStudentAccountSchema);

/* Admin table */
$sqlCreateAdminAccountSchema = "CREATE TABLE IF NOT EXISTS admin_account (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id VARCHAR(50) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50) NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    email VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    photo BLOB,
    f_create VARCHAR(2),
    f_update VARCHAR(2),
    f_delete VARCHAR(2),
    s_create VARCHAR(2),
    s_update VARCHAR(2),
    s_delete VARCHAR(2),
    a_create VARCHAR(2),
    a_update VARCHAR(2),
    a_delete VARCHAR(2),
    c_create VARCHAR(2),
    c_update VARCHAR(2),
    c_delete VARCHAR(2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
execOrDie($conn, $sqlCreateAdminAccountSchema);

/* Student Violation table — now with explicit CASCADE */
$sqlCreateStudentViolationSchema = "CREATE TABLE IF NOT EXISTS student_violation (
    violation_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(50) NOT NULL,
    offense_category ENUM('light', 'moderate', 'grave') NOT NULL,
    offense_type VARCHAR(50) NOT NULL,
    offense_details TEXT NOT NULL,
    description TEXT NOT NULL,
    photo BLOB,
    reported_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    KEY idx_sv_student_id (student_id),
    CONSTRAINT fk_sv_student
        FOREIGN KEY (student_id)
        REFERENCES student_account (student_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
execOrDie($conn, $sqlCreateStudentViolationSchema);

/* Violation Details table (FK points to student_violation) */
$sqlCreateViolationDetailsSchema = "CREATE TABLE IF NOT EXISTS violation_details (
    detail_id INT AUTO_INCREMENT PRIMARY KEY,
    violation_id INT NOT NULL,
    offense_code VARCHAR(100) NOT NULL,
    offense_label VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_violation_details_violation
        FOREIGN KEY (violation_id)
        REFERENCES student_violation(violation_id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
execOrDie($conn, $sqlCreateViolationDetailsSchema);

/* Student QR Keys table */
$sqlCreateStudentQrKeysSchema = "CREATE TABLE IF NOT EXISTS student_qr_keys (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(50) NOT NULL,
    qr_key CHAR(64) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    revoked TINYINT(1) DEFAULT 0,
    KEY idx_qr_student_id (student_id),
    CONSTRAINT fk_qr_student
        FOREIGN KEY (student_id)
        REFERENCES student_account(student_id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
execOrDie($conn, $sqlCreateStudentQrKeysSchema);

/**
 * 3b) Ensure the FK on student_violation actually cascades (covers existing DBs)
 *     - If an older FK exists without CASCADE, drop and recreate it
 *     - Ensure the index on student_violation(student_id) exists
 */
function ensureStudentViolationCascade($conn, $dbname) {
    // Ensure index exists (avoid duplicate by checking information_schema)
    $idxSql = "
        SELECT COUNT(*) AS c
        FROM information_schema.statistics
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'student_violation'
          AND COLUMN_NAME = 'student_id'
    ";
    $res = $conn->query($idxSql);
    if ($res) {
        $row = $res->fetch_assoc();
        if ((int)$row['c'] === 0) {
            // Add index if missing
            $addIdx = "ALTER TABLE student_violation ADD INDEX idx_sv_student_id (student_id)";
            if ($conn->query($addIdx) === FALSE) {
                handleQueryError($addIdx, $conn);
            }
        }
        $res->free();
    } else {
        handleQueryError($idxSql, $conn);
    }

    // Find FK(s) from student_violation → student_account
    $fkSql = "
        SELECT rc.CONSTRAINT_NAME, rc.UPDATE_RULE, rc.DELETE_RULE
        FROM information_schema.REFERENTIAL_CONSTRAINTS rc
        WHERE rc.CONSTRAINT_SCHEMA = DATABASE()
          AND rc.TABLE_NAME = 'student_violation'
          AND rc.REFERENCED_TABLE_NAME = 'student_account'
    ";
    $fkRes = $conn->query($fkSql);
    if ($fkRes === FALSE) {
        handleQueryError($fkSql, $conn);
    }

    $needFix = true;
    $existingFkName = null;
    if ($fkRes->num_rows > 0) {
        while ($fk = $fkRes->fetch_assoc()) {
            $existingFkName = $fk['CONSTRAINT_NAME'];
            if (strtoupper($fk['DELETE_RULE']) === 'CASCADE' && strtoupper($fk['UPDATE_RULE']) === 'CASCADE') {
                $needFix = false; // Already correct
                break;
            }
        }
    }
    $fkRes->free();

    if (!$needFix) {
        return; // All good
    }

    // Check for orphan rows that would block re-adding the FK
    $orphansSql = "
        SELECT COUNT(*) AS c
        FROM student_violation sv
        LEFT JOIN student_account sa ON sa.student_id = sv.student_id
        WHERE sa.student_id IS NULL
    ";
    $orphanRes = $conn->query($orphansSql);
    if ($orphanRes === FALSE) {
        handleQueryError($orphansSql, $conn);
    }
    $oc = (int)$orphanRes->fetch_assoc()['c'];
    $orphanRes->free();

    if ($oc > 0) {
        die(
            "Cannot enforce cascading FK on student_violation → student_account because there are {$oc} orphan row(s) in student_violation.\n" .
            "Fix suggestion:\n" .
            "  -- Inspect or delete orphans before proceeding\n" .
            "  SELECT sv.* FROM student_violation sv LEFT JOIN student_account sa ON sa.student_id = sv.student_id WHERE sa.student_id IS NULL;\n" .
            "  -- Example clean-up (DANGEROUS: deletes orphans)\n" .
            "  DELETE sv FROM student_violation sv LEFT JOIN student_account sa ON sa.student_id = sv.student_id WHERE sa.student_id IS NULL;\n"
        );
    }

    // Drop old FK if it exists
    if (!empty($existingFkName)) {
        $dropSql = "ALTER TABLE student_violation DROP FOREIGN KEY `$existingFkName`";
        if ($conn->query($dropSql) === FALSE) {
            handleQueryError($dropSql, $conn);
        }
    } else {
        // Some MySQL versions auto-name as student_violation_ibfk_1; attempt a best-effort drop (ignore errors)
        $conn->query("ALTER TABLE student_violation DROP FOREIGN KEY student_violation_ibfk_1");
    }

    // Recreate correct FK with CASCADEs
    $addFk = "ALTER TABLE student_violation
        ADD CONSTRAINT fk_sv_student
        FOREIGN KEY (student_id)
        REFERENCES student_account (student_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE";
    if ($conn->query($addFk) === FALSE) {
        handleQueryError($addFk, $conn);
    }
}

// Enforce cascade FK now (covers already-initialized DBs)
ensureStudentViolationCascade($conn, $dbname);

/**
 * 4) Smart redirect:
 *    - If there are no admins yet, go create one.
 *    - Otherwise, proceed to login.
 */
$adminCount = 0;
if ($result = $conn->query("SELECT COUNT(*) AS c FROM admin_account")) {
    $row = $result->fetch_assoc();
    $adminCount = (int)$row['c'];
    $result->free();
}
$conn->close();

if ($adminCount === 0) {
    header("Location: create_admin_account.php");
    exit();
} else {
    header("Location: login.php");
    exit();
}
